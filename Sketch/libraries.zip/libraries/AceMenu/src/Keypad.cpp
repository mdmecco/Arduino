// keypad codes
#include "Keypad.h"

const char Keypad::NOKEY = 0;
const char Keypad::DECKEYSHORT = 'd';
const char Keypad::DECKEYLONG = 'D';
const char Keypad::INCKEYSHORT = 'i';
const char Keypad::INCKEYLONG = 'I';
const char Keypad::SELKEYSHORT = 's';
const char Keypad::SELKEYLONG = 'S';
