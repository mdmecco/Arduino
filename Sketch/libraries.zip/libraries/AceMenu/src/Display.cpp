// misappropriated ASCII control codes used to control display
#include "Display.h"

const char Display::NEWLINE = '\n';
const char Display::CLRSCR = '\b';
const char Display::FLASHON = '\a';
const char Display::FLASHOFF = '\e';
